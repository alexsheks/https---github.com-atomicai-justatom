import styled from "styled-components";
import { CgArrowUpR as Icon } from "react-icons/cg";
export const Circle = styled.div`
  width: 250px;
  height: 250px;
  border-radius: 50%;
  display: flex;
  /* bottom: 50%; */

  align-items: center;
  justify-content: center;

  border: solid 3px black;
  flex-direction: column;
`;
export const CircleContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  width: 150px;
  height: 30px;
`;

export const WrapperCircle = styled.div``;
export const ArrowToAction = styled(Icon)`
  width: 200px;
`;
